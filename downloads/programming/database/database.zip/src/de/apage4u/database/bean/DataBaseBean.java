package de.apage4u.database.bean;

import de.apage4u.database.interfaces.DataHome;
import de.apage4u.database.interfaces.Data;
import de.apage4u.database.interfaces.DataExistsException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.ejb.EJBException;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Vector;

/** 
 *	This class contains the implementation for the `addData' method exposed by
 *  this Bean. It includes empty method bodies for the methods prescribed by
 *  the SessionBean interface; these don't need to do anything in this simple
 *  example.
 */
public class DataBaseBean implements SessionBean {
	/** 
	 * Helper function to get the home interface of a specified Bean. This is
	 * used by most of the methods in this class.
	 */
	private Object getHome (String path, Class type) {
		try {
			InitialContext jndiContext = new InitialContext();
			Object ref = jndiContext.lookup(path);
			
			return PortableRemoteObject.narrow(ref,type);
		} catch (Exception e) {
			throw new EJBException(e);
		}
	}

	/** Adds a Data to the database, if possible. If the Data already exists (that
	 *  is, there is already an entry in the database with the same `id' field)
	 *  then it throws a DataExistsException.
	 */
	public void addData(Integer id, String title, String artist, String type,
				String notes) throws DataExistsException, RemoteException {
		
		DataHome home = (DataHome) getHome("database/Data", DataHome.class);
		
		try {
			Data oldData = home.findByPrimaryKey(id);
			Integer dummy = oldData.getId(); 	// Force loading of data here
			// If we get here, the Data is already in the collection
			throw new DataExistsException();
			// Because we aren't dealing with air traffic control here, I will assume
			// that any exception generated from finding whether a Data exists in the
			// database is an indication that it doesn't, and therefore it's safe to
			// add it.
		} catch (Exception e) {
			System.out.println("Added Data with id=" + id + ", title=" + title
				+ ", artist=" + artist + ", type=" + type + ", notes=" + notes);
			try {
				Data data = home.create(id);
				data.setTitle(title);
				data.setArtist(artist);
				data.setType(type);
				data.setNotes(notes);
				
				return;
			} catch (Exception e2) {
				throw new EJBException (e2);
         	}
      	}
	}

   /**
    * Deletes all Datas from the database
    */
   public void deleteAll() throws RemoteException {
   	
	   DataHome home = (DataHome) getHome("database/Data", DataHome.class);
	   try {
		   Collection all = home.findAll();
		   System.out.println("***found all***");
		   Object[] datas = all.toArray();
		   System.out.println("*** num records = " + datas.length);
		   for (int i = 0; i < datas.length; i++) {
			   Data data = (Data) datas[i];
			   System.out.println("Deleting Data with id=" + data.getId());
				try {
               		data.remove();
            	} catch (RemoveException e) {
            		System.out.println (e.toString());
            	}
			}
			
		    return;
		} catch (FinderException e) {
		   // It's difficult to know what to do here; FinderException does _not_
		   // get thrown if the Data isn't found in the database: that gets us a
		   // RemoteException instead!
		   System.out.println("Caught FinderException in DataBase::deleteAll()");
		   
		   return;
		} catch (RemoteException e) {
		   // We will get here if the database is empty, and also if there is
		   // an error in configuration of the database access descriptor
		   System.out.println(e.toString());
		   
		   return ;
		}
	}

   /**
    * Returns an array of all Datas in the collection
    */
   public Data[] findAll() throws RemoteException, FinderException {
	   DataHome home = (DataHome) getHome("database/Data", DataHome.class);
	   Collection all = home.findAll();
	   
	   return (Data[]) all.toArray(new Data[0]);
	}

   /**
    * Returns an array of all Datas in the collection that have the specified
    * string in any part of any field. This is a very inefficient
    * implementation: it gets the complete list of Datas as objects, then
    * interates throw the list checking each field. This whole business could
    * be more efficiently carried out using a big SQL `select' statement, but
    * the whole point of Bean-managed persistence is to avoid explicit database
    * operations.
    */
   public Data[] lookupInAnyField(String _s) throws RemoteException, FinderException {
	   String s = _s.toLowerCase();
	   DataHome home = (DataHome) getHome("database/Data", DataHome.class);
	   Collection all = home.findAll();
	   Data[] datas = (Data[])all.toArray(new Data[0]);

	   Vector v = new Vector();
	   for (int i = 0; i < datas.length; i++) {
			boolean include = false;
			if (datas[i].getTitle().toLowerCase().indexOf(s) >= 0) include = true;
			if (datas[i].getArtist().toLowerCase().indexOf(s) >= 0) include = true;
			if (datas[i].getType().toLowerCase().indexOf(s) >= 0) include = true;
			if (datas[i].getNotes().toLowerCase().indexOf(s) >= 0) include = true;
			if (include)
				v.add(datas[i]);
		}

		Data dataOut[] = new Data[v.size()];
		for (int i = 0; i < v.size(); i++)
			dataOut[i] = (Data) v.get(i);
		
		return dataOut;
	}
	
	public void ejbCreate() {}
	public void ejbRemove() {}
	public void ejbActivate() {}
	public void ejbPassivate() {}
	public void setSessionContext(SessionContext sc) {}
	
}