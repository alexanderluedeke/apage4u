package de.apage4u.database.interfaces;

import javax.ejb.EJBObject;
import javax.ejb.FinderException;
import java.rmi.RemoteException;

/**
 * This interface defines the remote interface for the `DataBase' EJB, 
 * a data set.
 */
public interface DataBase extends EJBObject {

   /**
    * Adds a Data to the collection, if possible
    */
   public void addData(Integer id, String title, String artist, String type,
      String notes) throws RemoteException, DataExistsException;

   /**
    * Deletes all Datas from the database
    */
   public void deleteAll() throws RemoteException;

   public Data[] findAll() throws RemoteException, FinderException;

   public Data[] lookupInAnyField(String s) throws RemoteException, FinderException;
}

