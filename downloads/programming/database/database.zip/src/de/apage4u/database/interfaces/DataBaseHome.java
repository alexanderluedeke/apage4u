package de.apage4u.database.interfaces;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import java.rmi.RemoteException;

/**
 * This interface defines the home interface for the `DataBase' EJB.
 */
public interface DataBaseHome extends EJBHome {

   /**
    * Creates an instance of the `DataBaseBean' class on the server, and
    * returns a remote reference to a DataBase interface on the client.
    */
   DataBase create() throws RemoteException, CreateException;

}
