package de.apage4u.database.interfaces;

/**
 * This exception is thrown if the client tries to add a Data to the 
 * collection whose ID already exists in the database
 */
public class DataExistsException extends Exception {

   private String text;

   public DataExistsException(String _text) {
      text = _text;
   }

   public DataExistsException() {
      text = "A Data with this ID already exists";
   }

   public String toString() {
      return text;
   }

}

