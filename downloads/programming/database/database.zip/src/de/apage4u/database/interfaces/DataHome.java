package de.apage4u.database.interfaces;

import javax.ejb.EJBHome;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import java.rmi.RemoteException;
import java.util.Collection;

/**
 * This interface defines the home interface for the Data Bean
 */
public interface DataHome extends EJBHome {

   /**
    * Create a new Data instance
    */
   public Data create(Integer id) throws RemoteException, CreateException;

   /**
    * Find the Data with the specified ID. This method is implemented by the
    * container
    */
   public Data findByPrimaryKey (Integer id) throws RemoteException, FinderException;

   /**
    * Finds the Data whose "type" attribute matches that specified.
    * This method is implemented by the container
    */
   public Collection findByType (String type) throws RemoteException, FinderException;

   /**
    * Get all Data instances. This method is implemented by the container
    */
   public Collection findAll() throws RemoteException, FinderException;

}