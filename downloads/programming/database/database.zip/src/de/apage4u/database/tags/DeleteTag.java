package de.apage4u.database.tags;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

// For JNDI
import javax.naming.*;

import de.apage4u.database.interfaces.Data;
import de.apage4u.database.interfaces.DataHome;
import de.apage4u.database.interfaces.DataBase;
import de.apage4u.database.interfaces.DataBaseHome;

import javax.rmi.PortableRemoteObject;
import javax.naming.InitialContext;
import java.util.Hashtable;
import java.util.Properties;
import java.io.FileInputStream;
import java.util.StringTokenizer;

/**
 * Deletes one or all data sets.
 */
public class DeleteTag extends TagSupport {
	
	/**
	 *	Constructor.
	 */
	public DeleteTag() {
		super();
	}
    	
	/**
	 * Object already created from the jsp. (Just the name of the object)
	 */
	private String id = null;
	
	/**
	 * Method used by the JSP container to set the attribut.
	 */
	public void setId(String id) {
        this.id = id;
    }
	
	/**
	 * Object already created from the jsp. (Just the name of the object)
	 */
	private String all = null;
	
	/**
	 * Method used by the JSP container to set the attribut.
	 */
	public void setAll(String all) {
        this.all = all;
    }
    	
	/**
	 * Object to write the generated code to.
	 */
	JspWriter out = null;
	
	/**
	 * Entering the tag executes this method.
	 */
	public int doStartTag() throws JspTagException {
		try {
			/**
			 * Get the object in pageContext to write out.
			 * Don't initialize the field "out" with this statement 
			 * above it will throw a nullpointer exeception.
			 */			
			out = pageContext.getOut();

			// Get a naming context
			InitialContext jndiContext = new InitialContext();
	
			// Get a reference to a Data Bean
			Object ref  = jndiContext.lookup("database/DataBase");
	
			// Get a reference from this to the Bean's Home interface
			DataBaseHome home = 
			   (DataBaseHome) PortableRemoteObject.narrow (ref, DataBaseHome.class);
	
			DataBase dataBase = home.create();
			
			// Get a reference to a Data Bean
			Object refData = jndiContext.lookup("database/Data");
		
			// Get a reference to the Data Bean's Home interface
			DataHome dataHome = 
				(DataHome) PortableRemoteObject.narrow (refData, DataHome.class);
		
			if (all != null && all.equals("true") && id == null) {
				
				// Process the whole database
				try {	
					Data[] datas = dataBase.findAll();
					
					for (int i = 0; i < datas.length; i++) {
						System.out.println ("Removing " +
							datas[i].getId() + "\t" +
							datas[i].getTitle());
						Data eachData = dataHome.findByPrimaryKey(datas[i].getId());
						eachData.remove();
					}
				} catch(Exception e) {
					System.out.println(e.toString());
				}

				out.println("<H4>Alle Datens&auml;tze entfernt</H4>");
				
			} else if ((all == null || !all.equals("true")) && id != null) {
				
				// Remove the data set with the given Id
				try {
					if (dataHome.findByPrimaryKey(Integer.valueOf(id)) != null) {
						Data eachData = dataHome.findByPrimaryKey(Integer.valueOf(id));
						eachData.remove();
						out.println("<H4>Entfernt</H4>" + 
						"Der Datensatz mit der Id " + id + " wurde entfernt.");
					}
				} catch (javax.ejb.ObjectNotFoundException oNFE) {
					out.println("<H4>Nicht entfernt</H4>" + 
						"Der Datensatz mit der Id " + id + 
						" konnte nicht entfernt werden, weil er nicht existiert.");
				}	
			}
					
		} catch(java.io.IOException iOE) {
			throw new JspTagException(">>>IOException: " + iOE.getMessage()); 
		} catch (javax.naming.NamingException nE) {
			throw new JspTagException(">>>NamingException: " + nE.getMessage()); 
		} catch(java.lang.NullPointerException nPE) {
			throw new JspTagException(">>>NullPointerException: " + nPE.getMessage()); 
		} catch(java.lang.IllegalArgumentException iAE) {
			throw new JspTagException(">>>IllegalArgumentException: " + iAE.getMessage()); 
		} catch(javax.ejb.RemoveException rE) {
			throw new JspTagException(">>>RemoveException: " + rE.getMessage()); 
		} catch(javax.ejb.CreateException cE) {
			throw new JspTagException(">>>CreateException: " + cE.getMessage()); 
		} catch(javax.ejb.FinderException fE) {
			throw new JspTagException(">>>FinderException: " + fE.getMessage()); 
		}
			
		return EVAL_PAGE;
	}

	/**
	 * Method called to release all resources
	 */
	public void release() {}

}

