package de.apage4u.database.tags;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

// For JNDI
import javax.naming.*;

import de.apage4u.database.interfaces.Data;
import de.apage4u.database.interfaces.DataHome;
import de.apage4u.database.interfaces.DataBase;
import de.apage4u.database.interfaces.DataBaseHome;
import de.apage4u.database.interfaces.DataExistsException;
import de.apage4u.database.utils.FileLineReader;
import de.apage4u.database.utils.TokenizerWithBlanks;

import javax.rmi.PortableRemoteObject;
import javax.naming.InitialContext;
import java.util.Hashtable;
import java.util.Properties;
import java.io.FileInputStream;
import java.util.StringTokenizer;

/**
 * Inserts one data set or a file containing some data.
 */
public class InsertTag extends TagSupport {
	
	/**
	 *	Constructor.
	 */
	public InsertTag() {
		super();
	}
	
	/**
	 * Object already created from the jsp. (Just the name of the object)
	 */
	private String fileString = "";
	
	/**
	 * Method used by the JSP container to set the attribut.
	 */
	public void setFileString(String fileString) {
        this.fileString = fileString;
    }
    	
	/**
	 * Object already created from the jsp. (Just the name of the object)
	 */
	private String id = "";
	
	/**
	 * Method used by the JSP container to set the attribut.
	 */
	public void setId(String id) {
        this.id = id;
    }
	
	/**
	 * Object already created from the jsp. (Just the name of the object)
	 */
	private String title = "";
	
	/**
	 * Method used by the JSP container to set the attribut.
	 */
	public void setTitle(String title) {
        this.title = title;
    }
    	
	/**
	 * Object already created from the jsp. (Just the name of the object)
	 */
	private String artist = "";
	
	/**
	 * Method used by the JSP container to set the attribut.
	 */
	public void setArtist(String artist) {
        this.artist = artist;
    }
    	
	/**
	 * Object already created from the jsp. (Just the name of the object)
	 */
	private String type = "";
	
	/**
	 * Method used by the JSP container to set the attribut.
	 */
	public void setType(String type) {
        this.type = type;
    }
    	
	/**
	 * Object already created from the jsp. (Just the name of the object)
	 */
	private String notes = "";
	
	/**
	 * Method used by the JSP container to set the attribut.
	 */
	public void setNotes(String notes) {
        this.notes = notes;
    }

	/**
	 * Object to write the generated code to.
	 */
	JspWriter out = null;
	
	/**
	 * Entering the tag executes this method.
	 */
	public int doStartTag() throws JspTagException {
		try {
			/**
			 * Get the object in pageContext to write out.
			 * Don't initialize the field "out" with this statement 
			 * above it will throw a nullpointer exeception.
			 */			
			out = pageContext.getOut();

			// Get a naming context
			InitialContext jndiContext = new InitialContext();
	
			// Get a reference to a Data Bean
			Object ref  = jndiContext.lookup("database/DataBase");
	
			// Get a reference from this to the Bean's Home interface
			DataBaseHome home = 
			   (DataBaseHome) PortableRemoteObject.narrow (ref, DataBaseHome.class);
	
			DataBase dataBase = home.create();
		
			if (fileString != null) {
	
				dataBase.deleteAll();
		
				FileLineReader flr = new FileLineReader(fileString);
				boolean more = true;
				int i = 0;
				do {
					String s = flr.readLine();
					i++;
					if (s == null)
					   more = false;
					else {
						if (s == "") continue;
						String[] tokens = TokenizerWithBlanks.tokenize(s, '\t');
						int numTokens = tokens.length;
						if (numTokens == 5) {
							String id = tokens[0];
							String title = tokens[1];
							String artist = tokens[2];
							String type = tokens[3];
							String notes = tokens[4];
							System.out.println("id="+Integer.valueOf(id));
							try {
							   dataBase.addData(Integer.valueOf(id), title, artist, type, notes);
							} catch (DataExistsException e) {
								System.err.println ("uploadFile: duplicate ID on line "
									+ i + " (ID is " + id + ")");
							}
						}
						else
							System.err.println ("uploadFile: wrong number of fields on line "
							+ i
							+ " in file `" + fileString + "'");
					}
				} while (more);
			
				out.println("Beispiel-Datens&auml;tze eingef&uuml;gt");
				
			} else {
			
				// I need a second object references, for each Data.
			
				// Get a reference to a Data Bean
				Object refData = jndiContext.lookup("database/Data");
			
				// Get a reference to the Data Bean's Home interface
				DataHome dataHome = 
					(DataHome) PortableRemoteObject.narrow (refData, DataHome.class);
				
				// Test if the id is already used
				try {
					if (dataHome.findByPrimaryKey(Integer.valueOf(id)) != null)
						out.println("<H4>Nicht eingef&uuml;gt</H4>\nDie gew&auml;hlte Id (" + 
							id + ") ist bereits vergeben." +
							"<BR><BR>erneut einen <A href='insert.jsp' target='_data'>Datensatz einf&uuml;gen</A>");
				} catch (javax.ejb.ObjectNotFoundException oNFE) {
					try {
						dataBase.addData(Integer.valueOf(id), title, artist, type, notes);
					} catch (DataExistsException e) {
						out.println("uploadFile: duplicate ID " + id + ")");
					}
					out.print("<H4>Eingef&uuml;gt</H4>");
					out.println("Datensatz erfolgreich eingef&uuml;gt");
				}
				
			}
					
		} catch(java.io.IOException iOE) {
			throw new JspTagException(">>>IOException: " + iOE.getMessage()); 
		} catch (javax.naming.NamingException nE) {
			throw new JspTagException(">>>NamingException: " + nE.getMessage()); 
		} catch(java.lang.NullPointerException nPE) {
			throw new JspTagException(">>>NullPointerException: " + nPE.getMessage()); 
		} catch(java.lang.IllegalArgumentException iAE) {
			throw new JspTagException(">>>IllegalArgumentException: " + iAE.getMessage()); 
		} catch(javax.ejb.CreateException cE) {
			throw new JspTagException(">>>CreateException: " + cE.getMessage()); 
		} catch(javax.ejb.FinderException fE) {
			throw new JspTagException(">>>FinderException: " + fE.getMessage()); 
		}
			
		return EVAL_PAGE;
	}

	/**
	 * Method called to release all resources
	 */
	public void release() {}

}

