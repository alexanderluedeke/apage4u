package de.apage4u.database.tags;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

// For JNDI
import javax.naming.*;

import de.apage4u.database.interfaces.Data;
import de.apage4u.database.interfaces.DataHome;
import de.apage4u.database.interfaces.DataBaseHome;
import de.apage4u.database.interfaces.DataBase;

import javax.rmi.PortableRemoteObject;
import javax.naming.InitialContext;
import java.util.Hashtable;
import java.util.Properties;
import java.io.FileInputStream;

/**
 * Prints all Data Objects on the server as a html tabel. If there 
 * are no Data Objects the tags body will be evaluated.
 */
public class ListTag extends TagSupport {
	
	/**
	 * Object to write the generated code to.
	 */
	JspWriter out = null;
	
	/**
	 *	Constructor.
	 */
	public ListTag() {
		super();
	}
	
	/**
	 * Object already created from the jsp. (Just the name of the object)
	 */
	private String searchString = "";
	
	/**
	 * Method used by the JSP container to set the attribut.
	 */
	public void setSearchString(String searchString) {
        this.searchString = searchString;
    }
	
	/**
	 * Entering the tag executes this method.
	 */
	public int doStartTag() throws JspTagException {
		try {
			/**
			 * Get the object in pageContext to write out.
			 * Don't initialize the field "out" with this statement 
			 * above it will throw a nullpointer exeception.
			 */			
			out = pageContext.getOut();

			/**
			 * Get initial context and list its contend.
			 */			
			InitialContext jndiContext = new InitialContext();
		
			// Get a reference to a Data Bean
			Object ref  = jndiContext.lookup("database/DataBase");
		
			// Get a reference from this to the Bean's Home interface
			DataBaseHome home = 
				(DataBaseHome) PortableRemoteObject.narrow (ref, DataBaseHome.class);
		
			DataBase dataBase = home.create();
		
			Data[] datas = dataBase.lookupInAnyField(searchString);
			
			if (datas.length > 0) {
				// List the database
				
				out.print("<TABLE width='100%' bgcolor='#10CEFF'>");
				out.print("\n<TR>" +
					"<TH>Id</TH>" +
					"<TH>Titel</TH>" +
					"<TH>K&uuml;nstler</TH>" +
					"<TH>Typ</TH>" +
					"<TH>Anmerkung</TH>" + 
					"<TH>Aktion</TH>");
				
				for (int i = 0; i < datas.length; i++) {
					    out.print("\n\t<TR>" +
					    	"<TD class='list'>" + datas[i].getId() + "</TD>" +
					    	"<TD class='list'>" + datas[i].getTitle() + "&nbsp;</TD>" +
							"<TD class='list'>" + datas[i].getArtist() + "&nbsp;</TD>" +
							"<TD class='list'>" + datas[i].getType() + "&nbsp;</TD>" +
							"<TD class='list'>" + datas[i].getNotes() + "&nbsp;</TD>" +
							"<TD class='list'>" + 
							"<A href='delete.jsp?id=" + datas[i].getId() + "'>" +
							"<IMG src='/database/jsp/images/delete.gif' width='18' height='18'" +
							" border='0' title='Datensatz entfernen'>" + 
							"</A>" +
							"</TD></TR>");
				}
				
				out.print("\n</TABLE>");
				
				// Do not evaluate the tags body, so ..
				return SKIP_BODY;
				
			}
			
		} catch(java.io.IOException iOE) {
			throw new JspTagException(">>>IOException: " + iOE.getMessage()); 
		} catch (javax.naming.NamingException nE) {
			throw new JspTagException(">>>NamingException: " + nE.getMessage()); 
		} catch(java.lang.NullPointerException nPE) {
			throw new JspTagException(">>>NullPointerException: " + nPE.getMessage()); 
		} catch(java.lang.IllegalArgumentException iAE) {
			throw new JspTagException(">>>IllegalArgumentException: " + iAE.getMessage()); 
		} catch(javax.ejb.CreateException cE) {
			throw new JspTagException(">>>IllegalArgumentException: " + cE.getMessage()); 
		} catch(javax.ejb.FinderException fE) {
			throw new JspTagException(">>>IllegalArgumentException: " + fE.getMessage()); 
		}
			
		return EVAL_PAGE;
	}

	/**
	 * Method called to release all resources
	 */
	public void release() {}

}

