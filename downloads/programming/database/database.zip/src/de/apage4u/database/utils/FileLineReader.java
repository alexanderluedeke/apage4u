package de.apage4u.database.utils;

/**
 * Convenience class for reading text files a line at a time
 */
public class FileLineReader extends java.io.BufferedReader {
	
	/**
	 * Constructs a new FileLineReader open on the specified filename
	 */
	public FileLineReader (String filename) throws java.io.FileNotFoundException {
	   super (new java.io.FileReader(filename));
	}

}


