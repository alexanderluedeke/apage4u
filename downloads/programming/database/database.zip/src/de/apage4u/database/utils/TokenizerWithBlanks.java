package de.apage4u.database.utils;

import java.util.Vector;

/**
 * This simple class has one method that tokenizes a string, but allows tokens
 * to be blanks. This is in contrast to the java.util.StringTokenizer class
 * that assumes that multiple delimiters are a single delimiter. This class is
 * designed to tokenize the output of spreadsheets, where not all cells have
 * entries
 */
public class TokenizerWithBlanks {

   /**
    * Tokenize the string `s' with the specified delimiter, returning the
    * tokens as an array of strings
    */
   public static String[] tokenize (String _input, char delimiter) {
	   Vector v = new Vector();

	   String input = new String (_input);
	   String token;
	   int pos;
	   do
		{
		   pos = input.indexOf(delimiter);
			if (pos >= 0) {
			   token = input.substring(0, pos);
			   input = input.substring(pos + 1);
			} else {
			   token = input;
			   input = "";
			}
		   v.add(token);
		} while (pos >= 0);

  	   String s[] = new String[v.size()];

      for (int i = 0; i < v.size(); i++)
         s[i] = (String)v.get(i);

	   return s;
	}

}
